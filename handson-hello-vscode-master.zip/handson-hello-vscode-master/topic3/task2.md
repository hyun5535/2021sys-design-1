# 課題 2 で変更するファイル

1. apple
2. pineapple
3. apple
4. apple
5. pineapple
6. apple
